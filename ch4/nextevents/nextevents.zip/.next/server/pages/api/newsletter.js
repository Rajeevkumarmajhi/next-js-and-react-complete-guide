"use strict";
(() => {
var exports = {};
exports.id = 527;
exports.ids = [527];
exports.modules = {

/***/ 1990:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "TR": () => (/* binding */ connectDatabase),
  "s7": () => (/* binding */ getEventComments),
  "qi": () => (/* binding */ insertDocument)
});

// UNUSED EXPORTS: getAllDocument

;// CONCATENATED MODULE: external "mongodb"
const external_mongodb_namespaceObject = require("mongodb");
;// CONCATENATED MODULE: ./helpers/db-util.js

async function connectDatabase() {
    const client = await external_mongodb_namespaceObject.MongoClient.connect("mongodb+srv://rajeevkumarmajhi:Gamerboy7@cluster0.4sbdhxa.mongodb.net/events?retryWrites=true&w=majority");
    return client;
}
async function insertDocument(client, collection, document) {
    let db = client.db();
    let result = await db.collection(collection).insertOne(document);
    return result;
}
async function getAllDocument(client, collection, sort) {
    let db = client.db();
    let documents = await db.collection("comments").find().sort(sort).toArray();
    return documents;
}
async function getEventComments(client, collection, sort, eventId) {
    let db = client.db();
    let documents = await db.collection("comments").find({
        "eventId": eventId
    }).sort(sort).toArray();
    return documents;
}


/***/ }),

/***/ 9668:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _helpers_db_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1990);

// const url = 'mongodb+srv://rajeevkumarmajhi:Gamerboy7@cluster0.4sbdhxa.mongodb.net/?retryWrites=true&w=majority';
// const client = new MongoClient(url);
// const dbName = 'events';
async function handler(req, res) {
    if (req.method === "POST") {
        const userEmail = req.body.email;
        if (!userEmail || !userEmail.includes("@")) {
            res.status(422).json({
                message: "Invalid Email Address"
            });
            return;
        }
        let client;
        try {
            client = await (0,_helpers_db_util__WEBPACK_IMPORTED_MODULE_0__/* .connectDatabase */ .TR)();
        } catch (error) {
            res.status(500).json({
                message: "DB cannot be connected"
            });
            return;
        }
        try {
            await (0,_helpers_db_util__WEBPACK_IMPORTED_MODULE_0__/* .insertDocument */ .qi)(client, "newsletters", {
                email: userEmail
            });
            client.close();
        } catch (error) {
            res.status(500).json({
                message: "Data cannot be inserted!"
            });
            return;
        }
        res.status(201).json({
            message: "Signed Up!"
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9668));
module.exports = __webpack_exports__;

})();