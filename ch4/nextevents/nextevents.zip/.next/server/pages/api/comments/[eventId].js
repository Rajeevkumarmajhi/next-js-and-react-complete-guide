"use strict";
(() => {
var exports = {};
exports.id = 774;
exports.ids = [774];
exports.modules = {

/***/ 1990:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "TR": () => (/* binding */ connectDatabase),
  "s7": () => (/* binding */ getEventComments),
  "qi": () => (/* binding */ insertDocument)
});

// UNUSED EXPORTS: getAllDocument

;// CONCATENATED MODULE: external "mongodb"
const external_mongodb_namespaceObject = require("mongodb");
;// CONCATENATED MODULE: ./helpers/db-util.js

async function connectDatabase() {
    const client = await external_mongodb_namespaceObject.MongoClient.connect("mongodb+srv://rajeevkumarmajhi:Gamerboy7@cluster0.4sbdhxa.mongodb.net/events?retryWrites=true&w=majority");
    return client;
}
async function insertDocument(client, collection, document) {
    let db = client.db();
    let result = await db.collection(collection).insertOne(document);
    return result;
}
async function getAllDocument(client, collection, sort) {
    let db = client.db();
    let documents = await db.collection("comments").find().sort(sort).toArray();
    return documents;
}
async function getEventComments(client, collection, sort, eventId) {
    let db = client.db();
    let documents = await db.collection("comments").find({
        "eventId": eventId
    }).sort(sort).toArray();
    return documents;
}


/***/ }),

/***/ 3582:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _helpers_db_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1990);

// const url = 'mongodb+srv://rajeevkumarmajhi:Gamerboy7@cluster0.4sbdhxa.mongodb.net/?retryWrites=true&w=majority';
// const client = new MongoClient(url);
// const dbName = 'events';
async function handler(req, res) {
    const eventId = req.query.eventId;
    let client;
    try {
        client = await (0,_helpers_db_util__WEBPACK_IMPORTED_MODULE_0__/* .connectDatabase */ .TR)();
    } catch (error) {
        res.status(500).json("DB cannot be connected");
        return;
    }
    if (req.method == "POST") {
        const { email , name , text  } = req.body;
        if (!email.includes("@") || !name || name.trim === "" || !text || text.trim === "") {
            res.status(422).json({
                message: "Invalid Input"
            });
            client.close();
            return;
        }
        const newComment = {
            email,
            name,
            text,
            eventId
        };
        let result;
        try {
            result = await (0,_helpers_db_util__WEBPACK_IMPORTED_MODULE_0__/* .insertDocument */ .qi)(client, "comments", newComment);
            newComment._id = result.insertedId;
            res.status(201).json({
                message: "Comment saved successfully",
                comment: newComment
            });
        } catch (error) {
            res.status(500).json({
                message: "Comment insert failed"
            });
        }
    }
    if (req.method == "GET") {
        try {
            let documents = await (0,_helpers_db_util__WEBPACK_IMPORTED_MODULE_0__/* .getEventComments */ .s7)(client, "comments", {
                _id: -1
            }, eventId);
            res.status(200).json({
                comments: documents
            });
        } catch (error) {
            res.status(500).json({
                message: "Data fetching failed!"
            });
        }
    }
    client.close();
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3582));
module.exports = __webpack_exports__;

})();